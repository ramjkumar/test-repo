document.addEventListener('DOMContentLoaded', function () {
  const btn = document.querySelector('.back-to-top');
  const footer = document.querySelector('footer.footer-default');
  if (!btn || !footer) return;

  const defaultBottom = 30; // matches CSS
  const gap = 10; // gap above footer

  function update() {
    const rect = footer.getBoundingClientRect();
    const overlap = window.innerHeight - rect.top;
    if (overlap > 0) {
      // footer is visible; move button above footer
      btn.style.bottom = `${overlap + gap}px`;
    } else {
      btn.style.bottom = `${defaultBottom}px`;
    }
  }

  // initial
  update();
  window.addEventListener('scroll', update, { passive: true });
  window.addEventListener('resize', update);
});
