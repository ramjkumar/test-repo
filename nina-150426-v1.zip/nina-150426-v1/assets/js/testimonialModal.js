document.addEventListener('DOMContentLoaded', function () {
  const overlay = document.getElementById('testimonial-modal-overlay');
  const modal = document.getElementById('testimonial-modal');
  if (!modal || !overlay) return;
  const contentEl = modal.querySelector('.testimonial-modal-content');
  const closeBtn = modal.querySelector('.testimonial-modal-close');

  let _lastFocused = null;

  function openModal(html) {
    // save focused element to restore later
    _lastFocused = document.activeElement;

    // parse the incoming testimonial html and extract parts
    const tmp = document.createElement('div');
    tmp.innerHTML = html;
    const ratingsEl = tmp.querySelector('.ratings');
    const paragraphEl = tmp.querySelector('p');
    const authorEl = tmp.querySelector('.author-quote-item');

    // build header (ratings + close button)
    let header = modal.querySelector('.testimonial-modal-header');
    if (!header) {
      header = document.createElement('div');
      header.className = 'testimonial-modal-header';
      modal.insertBefore(header, contentEl);
    } else {
      header.innerHTML = '';
    }
    if (ratingsEl) header.appendChild(ratingsEl);
    // move close button into header (ensures it stays in header)
    header.appendChild(closeBtn);

    // populate body (scrollable area)
    contentEl.innerHTML = '';
    const bodyWrapper = document.createElement('div');
    bodyWrapper.className = 'testimonial-modal-body';
    if (paragraphEl) {
      bodyWrapper.appendChild(paragraphEl);
    } else {
      bodyWrapper.innerHTML = tmp.innerHTML;
    }
    contentEl.appendChild(bodyWrapper);

    // build footer (author/thumb/name)
    let footer = modal.querySelector('.testimonial-modal-footer');
    if (!footer) {
      footer = document.createElement('div');
      footer.className = 'testimonial-modal-footer';
      modal.appendChild(footer);
    } else {
      footer.innerHTML = '';
    }
    if (authorEl) footer.appendChild(authorEl);

    overlay.classList.add('open');
    modal.classList.add('open');
    // set aria
    modal.setAttribute('aria-hidden', 'false');
    overlay.setAttribute('aria-hidden', 'false');
    // prevent background scrolling
    document.body.classList.add('testimonial-modal-open');
    // focus close button for accessibility
    closeBtn.focus();
    document.addEventListener('keydown', onKeydown);
  }

  function closeModal() {
    modal.classList.remove('open');
    overlay.classList.remove('open');
    modal.setAttribute('aria-hidden', 'true');
    overlay.setAttribute('aria-hidden', 'true');
    // restore background scrolling
    document.body.classList.remove('testimonial-modal-open');
    // restore focus
    if (_lastFocused && typeof _lastFocused.focus === 'function') {
      _lastFocused.focus();
    }
    _lastFocused = null;
    document.removeEventListener('keydown', onKeydown);
  }

  function onKeydown(e) {
    if (e.key === 'Escape') closeModal();
  }

  // click handler: open modal with full testimonial HTML
  document.querySelectorAll('.testimonial-item .testimonial-content').forEach(function (el) {
    el.addEventListener('click', function (ev) {
      ev.preventDefault();
      // Use the full HTML of the testimonial-content so formatting remains intact
      openModal(el.innerHTML);
    });
  });

  // close interactions
  overlay.addEventListener('click', closeModal);
  closeBtn.addEventListener('click', closeModal);
});
