
document.addEventListener('DOMContentLoaded', function () {
    // Helper to get menu item info
    function getMenuItemInfo(menuItemElem) {
        const title = menuItemElem.querySelector('.title a').textContent.trim();
        const img = menuItemElem.querySelector('.menu-thumbnail img').getAttribute('src');
        const price = menuItemElem.querySelector('.price').textContent.trim();
        return { title, img, price };
    }

    // Update cart count badge (sum of quantities)
    function updateCartCount() {
        const items = document.querySelectorAll('.foodix-mini-cart-list li');
        let totalQty = 0;
        items.forEach(function (li) {
            const qtyElem = li.querySelector('.qty');
            const qty = qtyElem ? parseInt(qtyElem.textContent, 10) : 1;
            totalQty += isNaN(qty) ? 0 : qty;
        });
        const badge = document.getElementById('cart-count-badge');
        if (totalQty > 0) {
            badge.textContent = totalQty;
            badge.style.display = 'inline-block';
        } else {
            badge.style.display = 'none';
        }
        // Update total price if element present
        const totalAmountElem = document.getElementById('cart-total-amount');
        if (totalAmountElem) {
            let total = 0;
            items.forEach(function (li) {
                const lineElem = li.querySelector('.line-total');
                const line = lineElem ? parseFloat(lineElem.textContent.replace(/[^\d.]/g, '')) : 0;
                total += isNaN(line) ? 0 : line;
            });
            totalAmountElem.textContent = total.toFixed(2);
        }
    }

    // Animation: fly food image to cart
    function animateToCart(imgSrc, startRect, cartRect) {
        const flyingImg = document.createElement('img');
        flyingImg.src = imgSrc;
        flyingImg.className = 'flying-img';
        document.body.appendChild(flyingImg);
        // Set start position
        flyingImg.style.left = startRect.left + 'px';
        flyingImg.style.top = startRect.top + 'px';
        flyingImg.style.width = startRect.width + 'px';
        flyingImg.style.height = startRect.height + 'px';
        // Force reflow
        flyingImg.offsetWidth;
        // Animate to cart
        flyingImg.style.transform = `translate(${cartRect.left - startRect.left}px, ${cartRect.top - startRect.top}px) scale(0.3)`;
        flyingImg.style.opacity = '0.5';
        setTimeout(() => {
            flyingImg.remove();
        }, 800);
    }

    // Add to cart handler
    function handleAddToCart(e) {
        const addToCartElem = e.currentTarget;
        const menuItemElem = addToCartElem.closest('.menu-item');
        const info = getMenuItemInfo(menuItemElem);

        // Animation: fly image to cart
        const imgElem = menuItemElem.querySelector('.menu-thumbnail img');
        const imgRect = imgElem.getBoundingClientRect();
        const cartBtn = document.getElementById('main-cart-button');
        const cartRect = cartBtn.getBoundingClientRect();
        animateToCart(info.img, imgRect, cartRect);

        // If item already in cart, increase quantity
        const cartList = document.querySelector('.foodix-mini-cart-list');
        const existing = Array.from(cartList.querySelectorAll('li')).find(function (li) {
            const t = li.getAttribute('data-title');
            return t === info.title;
        });

        if (existing) {
            const qtyElem = existing.querySelector('.qty');
            const pricePerUnit = parseFloat(info.price.replace(/[^\d.]/g, '')) || 0;
            let qty = parseInt(qtyElem.textContent, 10) || 1;
            qty += 1;
            qtyElem.textContent = qty;
            const lineTotalElem = existing.querySelector('.line-total');
            if (lineTotalElem) lineTotalElem.textContent = (pricePerUnit * qty).toFixed(2);
            updateCartCount();
            return;
        }

        // Create cart item li with quantity controls
        const priceNum = parseFloat(info.price.replace(/[^\d.]/g, '')) || 0;
        const li = document.createElement('li');
        li.className = 'foodix-menu-cart';
        li.setAttribute('data-title', info.title);
        li.innerHTML = `
            <a href="#" class="remove-cart"><i class="far fa-trash-alt"></i></a>
            <a href="#" class="cart-item-link">
                <img src="${info.img}" alt="cart image">
                ${info.title}
            </a>
            <div class="cart-qty-price">
                <div class="qty-controls">
                    <button class="qty-decrease" aria-label="Decrease quantity">-</button>
                    <span class="qty">1</span>
                    <button class="qty-increase" aria-label="Increase quantity">+</button>
                </div>
                <div class="line-price"><span class="currency">£</span><span class="line-total">${priceNum.toFixed(2)}</span></div>
            </div>
        `;

        // Remove handler
        li.querySelector('.remove-cart').addEventListener('click', function (ev) {
            ev.preventDefault();
            li.remove();
            // Restore cart icon in menu
            const menuItems = document.querySelectorAll('.menu-item');
            menuItems.forEach(function (menuItem) {
                const titleElem = menuItem.querySelector('.title a');
                if (titleElem && titleElem.textContent.trim() === info.title) {
                    const addToCartBtn = menuItem.querySelector('.add-to-cart');
                    if (addToCartBtn) {
                        addToCartBtn.innerHTML = '<i class="fas fa-cart-plus"></i>';
                        addToCartBtn.classList.remove('in-cart');
                    }
                }
            });
            updateCartCount();
        });

        // Quantity controls
        const decBtn = li.querySelector('.qty-decrease');
        const incBtn = li.querySelector('.qty-increase');
        const qtyElem = li.querySelector('.qty');
        const lineTotalElem = li.querySelector('.line-total');

        function setQty(newQty) {
            newQty = Math.max(1, newQty);
            qtyElem.textContent = newQty;
            lineTotalElem.textContent = (priceNum * newQty).toFixed(2);
            updateCartCount();
        }

        decBtn.addEventListener('click', function (ev) {
            ev.preventDefault();
            const q = parseInt(qtyElem.textContent, 10) || 1;
            if (q > 1) setQty(q - 1);
        });
        incBtn.addEventListener('click', function (ev) {
            ev.preventDefault();
            const q = parseInt(qtyElem.textContent, 10) || 1;
            setQty(q + 1);
        });

        // Add to cart list and update
        cartList.appendChild(li);
        updateCartCount();

        // Change icon in menu to indicate item present
        addToCartElem.innerHTML = '<i class="fa-solid fa-check"></i>';
        addToCartElem.classList.add('in-cart');
    }

    // Remove from menu icon handler
    function handleDeleteFromMenu(e) {
        const addToCartElem = e.currentTarget;
        const menuItemElem = addToCartElem.closest('.menu-item');
        const info = getMenuItemInfo(menuItemElem);
        // Remove from cart list
        const cartList = document.querySelector('.foodix-mini-cart-list');
        const cartItems = cartList.querySelectorAll('li');
        cartItems.forEach(function (li) {
            const cartTitleElem = li.querySelector('a:nth-of-type(2)');
            if (cartTitleElem && cartTitleElem.textContent.trim() === info.title) {
                li.remove();
            }
        });
        updateCartCount();
        // Restore cart icon in menu
        addToCartElem.innerHTML = '<i class="fas fa-cart-plus"></i>';
        addToCartElem.classList.remove('in-cart');
        addToCartElem.removeEventListener('click', handleDeleteFromMenu);
        addToCartElem.addEventListener('click', handleAddToCart, { once: true });
    }

    // Attach to all add-to-cart elements
    document.querySelectorAll('.add-to-cart').forEach(function (elem) {
        elem.addEventListener('click', handleAddToCart, { once: true });
    });
    // Initial badge update (in case of pre-filled cart)
    updateCartCount();

    // --- Body scroll lock & focus trap when cart sidebar opens ---
    (function () {
        const cartEl = document.querySelector('.sidemenu-wrapper-cart');
        const overlayEl = document.querySelector('.offcanvas__overlay');
        if (!cartEl) return;

        let scrollY = 0;
        let keydownHandler = null;

        function setAriaHidden(isHidden) {
            document.querySelectorAll('body > *').forEach(el => {
                if (el === cartEl || el === overlayEl) return;
                if (isHidden) el.setAttribute('aria-hidden', 'true');
                else el.removeAttribute('aria-hidden');
            });
        }

        function lockBodyScroll() {
            scrollY = window.scrollY || document.documentElement.scrollTop || 0;
            const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
            document.body.style.position = 'fixed';
            document.body.style.top = `-${scrollY}px`;
            document.body.style.left = '0';
            document.body.style.right = '0';
            document.body.style.width = '100%';
            if (scrollbarWidth > 0) document.body.style.paddingRight = scrollbarWidth + 'px';
            setAriaHidden(true);
        }

        function unlockBodyScroll() {
            document.body.style.position = '';
            document.body.style.top = '';
            document.body.style.left = '';
            document.body.style.right = '';
            document.body.style.width = '';
            document.body.style.paddingRight = '';
            setAriaHidden(false);
            window.scrollTo(0, scrollY);
        }

        function getFocusable(container) {
            return Array.from(container.querySelectorAll('a, button, input, textarea, select, [tabindex]:not([tabindex="-1"])'))
                .filter(el => !el.hasAttribute('disabled') && el.offsetParent !== null);
        }

        function enableFocusTrap() {
            const focusables = getFocusable(cartEl);
            if (focusables.length) focusables[0].focus();

            keydownHandler = function (e) {
                if (e.key === 'Escape') {
                    // close cart
                    cartEl.classList.remove('info-open');
                    if (overlayEl) overlayEl.classList.remove('overlay-open');
                    return;
                }
                if (e.key === 'Tab') {
                    const nodes = getFocusable(cartEl);
                    if (nodes.length === 0) return;
                    const first = nodes[0];
                    const last = nodes[nodes.length - 1];
                    if (e.shiftKey) {
                        if (document.activeElement === first) {
                            e.preventDefault();
                            last.focus();
                        }
                    } else {
                        if (document.activeElement === last) {
                            e.preventDefault();
                            first.focus();
                        }
                    }
                }
            };
            document.addEventListener('keydown', keydownHandler);
        }

        function disableFocusTrap() {
            if (keydownHandler) {
                document.removeEventListener('keydown', keydownHandler);
                keydownHandler = null;
            }
        }

        function openActions() {
            lockBodyScroll();
            enableFocusTrap();
        }

        function closeActions() {
            disableFocusTrap();
            unlockBodyScroll();
        }

        // Observe class changes on the cart element so we react when theme.js opens/closes it
        const mo = new MutationObserver(function (mutations) {
            mutations.forEach(m => {
                if (m.attributeName === 'class') {
                    if (cartEl.classList.contains('info-open')) openActions();
                    else closeActions();
                }
            });
        });
        mo.observe(cartEl, { attributes: true });

        // Also ensure clicking close buttons triggers unlock immediately
        const closeBtns = Array.from(document.querySelectorAll('.sidemenu-cart-close, .offcanvas__overlay'));
        closeBtns.forEach(btn => btn.addEventListener('click', function () {
            // slight delay to allow theme.js handlers to toggle classes first
            setTimeout(() => { if (!cartEl.classList.contains('info-open')) closeActions(); }, 10);
        }));
    })();

    // WhatsApp share: build cart summary and open WhatsApp chat with message
    (function () {
        const cartShareBtn = document.querySelector('.sidemenu-wrapper-cart .cart-button a.contact-btn');
        if (!cartShareBtn) return;

        function buildCartMessage() {
            const cartList = document.querySelectorAll('.foodix-mini-cart-list li');
            if (!cartList || cartList.length === 0) return '';
            const lines = [];
            lines.push("Hello, I'd like to place an order from Nina's Home Food:");
            cartList.forEach(li => {
                const title = li.getAttribute('data-title') || (li.querySelector('a') && li.querySelector('a').textContent.trim()) || 'Item';
                const qty = li.querySelector('.qty') ? li.querySelector('.qty').textContent.trim() : '1';
                const lineTotal = li.querySelector('.line-total') ? li.querySelector('.line-total').textContent.trim() : '';
                const line = `- ${title} x ${qty}` + (lineTotal ? ` — £${lineTotal}` : '');
                lines.push(line);
            });
            const totalElem = document.getElementById('cart-total-amount');
            if (totalElem) lines.push(`Total: £${totalElem.textContent.trim()}`);
            lines.push('Please confirm availability and delivery details. Thank you!');
            return lines.join('\n');
        }

        cartShareBtn.addEventListener('click', function (e) {
            // build message from current cart
            const msg = buildCartMessage();
            if (!msg) {
                // if cart empty, allow default behaviour (link to generic contact)
                return; // let link follow
            }
            e.preventDefault();
            const baseHref = cartShareBtn.href || 'https://api.whatsapp.com/send';
            const sep = baseHref.includes('?') ? '&' : '?';
            const url = baseHref + sep + 'text=' + encodeURIComponent(msg);
            window.open(url, '_blank');
        });
    })();
});
